<template lang="html">
    <div class='container'>
        <h1>{{title}}</h1>
        <p>Tote Board for Wutsgotcha Downs</p>
        <races :races="races"></races>
    </div>
</template>

<script>

export default {
    data: function() {
        return {
        }
    }
}
</script>

<style lang="css">
</style>
