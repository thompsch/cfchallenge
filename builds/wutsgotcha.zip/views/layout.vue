<template>
    <!DOCTYPE html>
    <html lang="en">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
            <script src="js/vue.js"></script>
            <script src="js/vue-resource.js"></script>
            <script src="js/jquery-3.2.1.min.js"></script>
            <script src="js/bootstrap.min.js"></script>
            <link rel='stylesheet' href='css/bootstrap.min.css' />
        </head>
        <body>
            {{{app}}}
            {{{script}}}
        </body>
    </html>
</template>
<style>
</style>
