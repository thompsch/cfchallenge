<template lang='html'>
  <div>
      <p>{{results[raceid]}}</p>
  </div>
</template>

<script>
export default {
   props: ['raceid', 'results']
}
</script>

<style lang='css'>
</style>
